/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bill_generator;

/**
 *
 * @author DELL
 */
public class Bill_Generator {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
